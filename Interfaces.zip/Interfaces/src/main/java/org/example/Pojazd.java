package org.example;

public interface Pojazd {

    public void start();

    public void stop();

    public void jazda(int predkosc);
}