public class SamochodFiat extends Samochod {

    @Override
    public void drift() {
        System.out.println("Drift realizowany przez SamochodFiat");
    }
}