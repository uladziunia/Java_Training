public class RowerModelKK extends Rower {
    @Override
    public double skok(double wysokosc) {
        System.out.println("Skok realizowany przez RowerModelKK");
        return 0;
    }
}