public abstract class Rower implements Pojazd {

    public void start() {
        System.out.println("Start realizowany przez rower");
    }

    @Override
    public void stop() {
        System.out.println("Stop realizowany przez rower");
    }

    @Override
    public void jazda(int predkosc) {
        System.out.println("Jazda realizowana przez rower");
    }

    public abstract double skok(double wysokosc);
}