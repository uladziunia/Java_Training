public abstract class Samochod implements Pojazd {

    @Override
    public void start() {
        System.out.println("Start realizowany przez samochod");
    }

    @Override
    public void stop() {
        System.out.println("Stop realizowany przez samochod");
    }

    @Override
    public void jazda(int predkosc) {
        System.out.println("Jazda realizowana przez samochod");
    }

    public abstract void drift();
}