public class Main {

    public static void test00(Pojazd pojazd) {
    pojazd.start();
    pojazd.jazda(0);
    pojazd.stop();
    }

    private static void test00(SamochodFiat samochodzikKK) {
    }

    public static void main(String[] args) {
        RowerModelKK rowerekKK = new RowerModelKK();
        SamochodFiat samochodzikKK = new SamochodFiat();
        test00(rowerekKK);
        test00(samochodzikKK);
    }

    private static class SamochodFiat {
    }
}